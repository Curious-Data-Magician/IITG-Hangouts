from django.db import models

# Create your models here.
class Snippet(models.Model):
    pass